package banHang;

import org.junit.Test;
import org.mockito.Mockito.*;
import org.mockito.Mock;

import java.util.List;

import static org.junit.Assert.*;

public class banHangService_IMPLTest {


    // Tạo một đối tượng banHangService_IMPL

    banHangService_IMPL bhService = new banHangService_IMPL();

//    test gethoaDon
    @Test
    public void TestGetHoaDonNull(){


        // Gọi phương thức để lấy danh sách hóa đơn
        List<banHang> listHd = bhService.getHoaDon();

        // Kiểm tra xem danh sách hóa đơn có rỗng hay không
        assertFalse("Danh sách hóa đơn không được rỗng", listHd.isEmpty());
    }
    @Test
    public void TestGetHoaDon(){

        // Gọi phương thức để lấy danh sách hóa đơn
        List<banHang> listHd = bhService.getHoaDon();

        // Kiểm tra các thuộc tính của phần tử đầu tiên trong danh sách
        banHang firstHd = listHd.get(0);
        assertNotNull("Đối tượng hóa đơn không được null", firstHd);
    }
    @Test
    public void TestGetHoaDonIDNull(){

        // Gọi phương thức để lấy danh sách hóa đơn
        List<banHang> listHd = bhService.getHoaDon();

        // Kiểm tra các thuộc tính của phần tử đầu tiên trong danh sách
        banHang firstHd = listHd.get(0);
        assertNotNull("ID hóa đơn không được null", firstHd.getId_hoaDon());
    }
    @Test
    public void TestGetHoaDonTenNvNull(){

        // Gọi phương thức để lấy danh sách hóa đơn
        List<banHang> listHd = bhService.getHoaDon();

        // Kiểm tra các thuộc tính của phần tử đầu tiên trong danh sách
        banHang firstHd = listHd.get(0);
        assertNotNull("Tên nhân viên không được null", firstHd.getTenNhanVien());
    }
    @Test
    public void TestGetHoaDonNgayTaoNull(){

        // Gọi phương thức để lấy danh sách hóa đơn
        List<banHang> listHd = bhService.getHoaDon();
        // Kiểm tra các thuộc tính của phần tử đầu tiên trong danh sách
        banHang firstHd = listHd.get(0);
        assertNotNull("Ngày tạo không được null", firstHd.getNgayTao());
    }


    //test getSanPham
    @Test
    public void testGetSanPhamNull(){
        String timKiem="Giày đá bóng puma";
        List<banHang> result = bhService.getSanPham(timKiem);

        // Kiểm tra xem danh sách sản phẩm có rỗng hay không
        assertFalse("Danh sách sản phẩm không được rỗng", result.isEmpty());
    }
    @Test
    public void testGetSanPham(){
        String timKiem="Giày đá bóng puma";
        List<banHang> result = bhService.getSanPham(timKiem);
        // Kiểm tra các thuộc tính của phần tử đầu tiên trong danh sách
        banHang firstSp = result.get(0);
        assertNotNull("Đối tượng sản phẩm không được null", firstSp);
    }
    @Test
    public void testGetIDSanPhamNull(){
        String timKiem="Giày đá bóng puma";
        List<banHang> result = bhService.getSanPham(timKiem);
        // Kiểm tra các thuộc tính của phần tử đầu tiên trong danh sách
        banHang firstSp = result.get(0);
        assertNotNull("Đối tượng sản phẩm không được null", firstSp);
    }
    @Test
    public void testGetTenSanPhamNull(){
        String timKiem="Giày đá bóng puma";
        List<banHang> result = bhService.getSanPham(timKiem);
        // Kiểm tra các thuộc tính của phần tử đầu tiên trong danh sách
        banHang firstSp = result.get(0);
        assertNotNull("Tên sản phẩm không được null", firstSp.getTenSanPham());
    }
    @Test
    public void testGetTenSanPhamNotTonTai(){
        String timKiem="Giày đá bóng puma1";
        List<banHang> result = bhService.getSanPham(timKiem);
        // Kiểm tra các thuộc tính của phần tử đầu tiên trong danh sách
        banHang firstSp = result.get(0);
        assertNotNull("Tên sản phẩm không tồn tại", firstSp.getTenSanPham());
    }
    @Test
    public void testGetTenSanPhamRong(){
        String timKiem="";
        List<banHang> result = bhService.getSanPham(timKiem);
        // Kiểm tra các thuộc tính của phần tử đầu tiên trong danh sách
        banHang firstSp = result.get(0);
        assertFalse("Danh sách sản phẩm không được rỗng", result.isEmpty());
    }
    @Test
    public void testGetTenSanPhamKiTUDacBiet(){
        String timKiem="@";
        List<banHang> result = bhService.getSanPham(timKiem);
        // Kiểm tra các thuộc tính của phần tử đầu tiên trong danh sách
        banHang firstSp = result.get(0);
        assertEquals("sản phẩm không được chứa kí tự đặc biệt", result.isEmpty());
    }

    @Test
    public void testTaoHoaDon(){
        banHang bh = new banHang();
        bh.setNgayTao("2024-04-04");
        bh.setTrangThai(1);
        bh.setId_khachHang(1);
        bh.setTenNhanVien("Tên NV");

        // Gọi phương thức cần kiểm thử
        bhService.taoHoaDon(bh);

        assertEquals("2024-04-04", bh.getNgayTao());
        assertEquals("1", String.valueOf(bh.getTrangThai()));
        assertEquals("1", String.valueOf(bh.getId_khachHang()));
        assertEquals("Tên NV", bh.getTenNhanVien());
    }
    @Test
    public void testTaoHoaDonNullNgayTao(){
        banHang bh = new banHang();
        bh.setTrangThai(1);
        bh.setId_khachHang(1);
        bh.setTenNhanVien("Tên NV");

        // Gọi phương thức cần kiểm thử
        bhService.taoHoaDon(bh);
        assertEquals(false,  String.valueOf(bh.getNgayTao()).isEmpty());
        assertEquals("1", String.valueOf(bh.getTrangThai()));
        assertEquals("1", String.valueOf(bh.getId_khachHang()));
        assertEquals("Tên NV", bh.getTenNhanVien());
    }
    @Test
    public void testTaoHoaDonTrangThaiKhongTonTai(){
        banHang bh = new banHang();
        bh.setNgayTao("2024-04-04");
        bh.setTrangThai(10);
        bh.setId_khachHang(1);
        bh.setTenNhanVien("Tên NV");

        // Gọi phương thức cần kiểm thử
        bhService.taoHoaDon(bh);

        assertEquals("2024-04-04", bh.getNgayTao());
        assertEquals(10, String.valueOf(bh.getTrangThai()));
        assertEquals("1", String.valueOf(bh.getId_khachHang()));
        assertEquals("Tên NV", bh.getTenNhanVien());
    }
    @Test
    public void testTaoHoaDonNullTrangThai(){
        banHang bh = new banHang();
        bh.setNgayTao("2024-04-04");
        bh.setId_khachHang(1);
        bh.setTenNhanVien("Tên NV");

        // Gọi phương thức cần kiểm thử
        bhService.taoHoaDon(bh);
        assertEquals(false,  String.valueOf(bh.getTrangThai()).isEmpty());
        assertEquals("2024-04-04", bh.getNgayTao());
        assertEquals("1", String.valueOf(bh.getId_khachHang()));
        assertEquals("Tên NV", bh.getTenNhanVien());
    }
    @Test
    public void testTaoHoaDonKhachHangKhongTonTai(){
        banHang bh = new banHang();
        bh.setNgayTao("2024-04-04");
        bh.setTrangThai(1);
        bh.setId_khachHang(100);
        bh.setTenNhanVien("Tên NV");

        // Gọi phương thức cần kiểm thử
        bhService.taoHoaDon(bh);

        assertEquals("2024-04-04", bh.getNgayTao());
        assertEquals("1", String.valueOf(bh.getTrangThai()));
        assertEquals(false, String.valueOf(bh.getId_khachHang()));
        assertEquals("Tên NV", bh.getTenNhanVien());
    }
    @Test
    public void testTaoHoaDonKhachHangNull(){
        banHang bh = new banHang();
        bh.setNgayTao("2024-04-04");
        bh.setTrangThai(1);
        bh.setTenNhanVien("Tên NV");

        // Gọi phương thức cần kiểm thử
        bhService.taoHoaDon(bh);

        assertEquals("2024-04-04", bh.getNgayTao());
        assertEquals("1", String.valueOf(bh.getTrangThai()));
        assertEquals("Tên NV", bh.getTenNhanVien());
        assertEquals(false,  String.valueOf(bh.getId_khachHang()).isEmpty());
    }
    @Test
    public void testTaoHoaDonTenNVNull(){
        banHang bh = new banHang();
        bh.setNgayTao("2024-04-04");
        bh.setTrangThai(1);
        bh.setId_khachHang(1);

        // Gọi phương thức cần kiểm thử
        bhService.taoHoaDon(bh);

        assertEquals("2024-04-04", bh.getNgayTao());
        assertEquals("1", String.valueOf(bh.getTrangThai()));
        assertEquals("1", String.valueOf(bh.getId_khachHang()));
        assertEquals(false,  String.valueOf(bh.getId_khachHang()).isEmpty());
    }
    @Test
    public void testTaoHoaDonNullAll(){
        banHang bh = new banHang();
        bh.setNgayTao(null);
        bh.setTenNhanVien(null);

        // Gọi phương thức cần kiểm thử
        bhService.taoHoaDon(bh);
        assertEquals(false,  String.valueOf(bh.getNgayTao()).isEmpty());
        assertEquals(false,  String.valueOf(bh.getTrangThai()).isEmpty());
        assertEquals(false,  String.valueOf(bh.getTrangThai()).isEmpty());
        assertEquals(false,  String.valueOf(bh.getId_khachHang()).isEmpty());
    }
    @Test
    public void testAddSanPham(){
        banHang bh = new banHang();
        bh.setId_hoaDon(10);
        bh.setId_sanPhamCt(2);
        bh.setSoLuongThem(5);
        bh.setGiaSp(100.0);


        // Gọi phương thức cần kiểm thử
        bhService.themSanPham(bh);
        assertEquals(10,bh.getId_hoaDon());
        assertEquals(2,bh.getId_sanPhamCt());
        assertEquals(5,bh.getSoLuongThem());
        assertEquals(String.valueOf(100.0),String.valueOf(bh.getGiaSp()));
    }
    @Test
    public void testAddSanPhamNullIDHoaDon(){
        banHang bh = new banHang();
        bh.setId_sanPhamCt(2);
        bh.setSoLuongThem(5);
        bh.setGiaSp(100.0);


        // Gọi phương thức cần kiểm thử
        bhService.themSanPham(bh);
        assertEquals(2,bh.getId_sanPhamCt());
        assertEquals(5,bh.getSoLuongThem());
        assertEquals(String.valueOf(100.0),String.valueOf(bh.getGiaSp()));
    }
    @Test
    public void testAddSanPhamnullIdSpct(){
        banHang bh = new banHang();
        bh.setId_hoaDon(10);
        bh.setSoLuongThem(5);
        bh.setGiaSp(100.0);


        // Gọi phương thức cần kiểm thử
        bhService.themSanPham(bh);
        assertEquals(10,bh.getId_hoaDon());
        assertEquals(5,bh.getSoLuongThem());
        assertEquals(String.valueOf(100.0),String.valueOf(bh.getGiaSp()));
    }
    @Test
    public void testAddSanPhamNullSoLuongThem(){
        banHang bh = new banHang();
        bh.setId_hoaDon(10);
        bh.setId_sanPhamCt(2);
        bh.setGiaSp(100.0);


        // Gọi phương thức cần kiểm thử
        bhService.themSanPham(bh);
        assertEquals(10,bh.getId_hoaDon());
        assertEquals(2,bh.getId_sanPhamCt());
        assertEquals(String.valueOf(100.0),String.valueOf(bh.getGiaSp()));
    }
    @Test
    public void testAddSanPhamMinSoLluonThem(){
        banHang bh = new banHang();
        bh.setId_hoaDon(10);
        bh.setId_sanPhamCt(2);
        bh.setSoLuongThem(0);
        bh.setGiaSp(100.0);


        // Gọi phương thức cần kiểm thử
        bhService.themSanPham(bh);
        assertEquals(10,bh.getId_hoaDon());
        assertEquals(2,bh.getId_sanPhamCt());
        assertEquals(0,bh.getSoLuongThem());
        assertEquals(String.valueOf(100.0),String.valueOf(bh.getGiaSp()));
    }
    @Test
    public void testAddSanPhamMaxSoluongthem(){
        banHang bh = new banHang();
        bh.setId_hoaDon(10);
        bh.setId_sanPhamCt(2);
        bh.setSoLuongThem(1000000);
        bh.setGiaSp(100.0);


        // Gọi phương thức cần kiểm thử
        bhService.themSanPham(bh);
        assertEquals(10,bh.getId_hoaDon());
        assertEquals(2,bh.getId_sanPhamCt());
        assertEquals(1000000,bh.getSoLuongThem());
        assertEquals(String.valueOf(100.0),String.valueOf(bh.getGiaSp()));
    }
    @Test
    public void testAddSanPhamAmSoluongthem(){
        banHang bh = new banHang();
        bh.setId_hoaDon(10);
        bh.setId_sanPhamCt(2);
        bh.setSoLuongThem(-1);
        bh.setGiaSp(100.0);


        // Gọi phương thức cần kiểm thử
        bhService.themSanPham(bh);
        assertEquals(10,bh.getId_hoaDon());
        assertEquals(2,bh.getId_sanPhamCt());
        assertEquals(-1,bh.getSoLuongThem());
        assertEquals(String.valueOf(100.0),String.valueOf(bh.getGiaSp()));
    }
    @Test
    public void testAddSanPhamSoluongthemString(){
        banHang bh = new banHang();
        bh.setId_hoaDon(10);
        bh.setId_sanPhamCt(2);
        bh.setSoLuongThem(Integer.parseInt("một"));
        bh.setGiaSp(100.0);


        // Gọi phương thức cần kiểm thử
        bhService.themSanPham(bh);
        assertEquals(10,bh.getId_hoaDon());
        assertEquals(2,bh.getId_sanPhamCt());
        assertEquals("một",bh.getSoLuongThem());
        assertEquals(String.valueOf(100.0),String.valueOf(bh.getGiaSp()));
    }
}